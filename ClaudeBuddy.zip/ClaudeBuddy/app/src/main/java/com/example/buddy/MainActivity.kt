package com.example.buddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val u = resources.displayMetrics.density
        val prefs = getSharedPreferences("buddy", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (24 * u).toInt()
            setPadding(p, p * 2, p, p)
        }
        col.addView(TextView(this).apply {
            text = "Claude Buddy"; textSize = 26f
        })
        col.addView(TextView(this).apply {
            text = "Талисман, который ходит по экрану поверх всех приложений. Нажмите на него, чтобы задать вопрос."
            setPadding(0, (8 * u).toInt(), 0, (16 * u).toInt())
        })
        val key = EditText(this).apply {
            hint = "Ключ Gemini (AIza…) или Anthropic (sk-ant-…)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        col.addView(key)
        fun btn(label: String, click: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { click() }
        }.also { col.addView(it) }

        btn("1. Разрешить показ поверх других окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Запустить талисман") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала разрешите показ поверх окон", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                startForegroundService(Intent(this, BuddyService::class.java))
            }
        }
        btn("Остановить") { stopService(Intent(this, BuddyService::class.java)) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
