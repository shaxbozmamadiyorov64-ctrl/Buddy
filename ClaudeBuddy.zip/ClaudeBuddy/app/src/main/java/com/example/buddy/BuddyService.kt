package com.example.buddy

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BuddyService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var buddy: BuddyView
    private lateinit var bubble: TextView
    private lateinit var input: EditText
    private var u = 1f
    private var dir = 1
    private var mode = "walk"
    private var walkX = 0
    private var pauseUntil = 0L
    private var busy = false
    private var expanded = false
    private val history = JSONArray()
    private val closeTask = Runnable { if (!busy) collapse() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        u = resources.displayMetrics.density
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "Buddy", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "buddy")
            .setContentTitle("Claude Buddy работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
        h.post(walk)
    }

    private fun rounded(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = 16 * u }
    private fun dp(v: Int) = (v * u).toInt()

    private fun build() {
        buddy = BuddyView(this)
        bubble = TextView(this).apply {
            visibility = View.GONE; textSize = 15f; setTextColor(0xFF2A1A3A.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xFFFFFFFF.toInt())
            maxWidth = dp(260); maxHeight = dp(220)
            movementMethod = ScrollingMovementMethod()
            setOnClickListener { if (!busy) collapse() }
        }
        input = EditText(this).apply {
            visibility = View.GONE; hint = "Спросите Claude…"; isSingleLine = true
            setTextColor(0xFF2A1A3A.toInt()); setHintTextColor(0xFF8A7AA0.toInt())
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(0xFFFFFFFF.toInt())
            setOnEditorActionListener { _, a, _ ->
                if (a == EditorInfo.IME_ACTION_SEND) {
                    val t = text.toString().trim()
                    if (t.isNotEmpty() && !busy) { text.clear(); ask(t) }
                    true
                } else false
            }
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(6) })
            addView(input, LinearLayout.LayoutParams(dp(260), -2).apply { bottomMargin = dp(6) })
            addView(buddy)
        }
        buddy.setOnClickListener { if (expanded) collapse() else openInput() }
        lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = 0; y = dp(48)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(root, lp)
    }

    private fun setMode(m: String) { mode = m; buddy.mood = m }

    private val walk = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            if (!expanded && mode == "walk") {
                if (now < pauseUntil) buddy.mood = "idle"
                else {
                    buddy.mood = "walk"
                    val maxX = resources.displayMetrics.widthPixels - dp(84)
                    lp.x += (dir * 2 * u).toInt()
                    if (lp.x >= maxX) { lp.x = maxX; dir = -1 } else if (lp.x <= 0) { lp.x = 0; dir = 1 }
                    if (Math.random() < 0.004) pauseUntil = now + 1500 + (Math.random() * 2500).toLong()
                    if (Math.random() < 0.002) dir = -dir
                    buddy.dir = dir
                    wm.updateViewLayout(root, lp)
                }
            } else if (expanded && mode == "walk") buddy.mood = "idle"
            h.postDelayed(this, 33)
        }
    }

    private fun imm() = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

    private fun openInput() {
        h.removeCallbacks(closeTask)
        expanded = true; walkX = lp.x
        setMode("listen")
        input.visibility = View.VISIBLE
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.x = 0
        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        wm.updateViewLayout(root, lp)
        input.requestFocus()
        h.postDelayed({ imm().showSoftInput(input, 0) }, 150)
    }

    private fun collapse() {
        h.removeCallbacks(closeTask)
        imm().hideSoftInputFromWindow(input.windowToken, 0)
        input.visibility = View.GONE; bubble.visibility = View.GONE
        expanded = false; setMode("walk")
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.gravity = Gravity.BOTTOM or Gravity.START; lp.x = walkX
        wm.updateViewLayout(root, lp)
    }

    private fun ask(text: String) {
        h.removeCallbacks(closeTask)
        busy = true; setMode("think")
        imm().hideSoftInputFromWindow(input.windowToken, 0)
        input.visibility = View.GONE
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, lp)
        bubble.text = "• • •"; bubble.visibility = View.VISIBLE
        while (history.length() > 8) history.remove(0)
        history.put(JSONObject().put("role", "user").put("content", text))
        Thread {
            val r = try { Result.success(call()) } catch (e: Exception) { Result.failure(e) }
            h.post { finish(r) }
        }.start()
    }

    private fun finish(r: Result<String>) {
        busy = false
        r.onSuccess {
            history.put(JSONObject().put("role", "assistant").put("content", it))
            bubble.text = it; setMode("happy")
            h.postDelayed({ if (mode == "happy") setMode("walk") }, 1800)
            h.postDelayed(closeTask, 8000L + it.length * 50L)
        }.onFailure {
            history.remove(history.length() - 1)
            bubble.text = "Не получилось: ${it.message}"; setMode("sad")
            h.postDelayed({ if (mode == "sad") setMode("walk") }, 2500)
            h.postDelayed(closeTask, 7000)
        }
    }

    private fun call(): String {
        val key = getSharedPreferences("buddy", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) throw Exception("не задан ключ API")
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 400)
            .put("system", "Ты милый маленький талисман-помощник на экране телефона. Отвечай на языке пользователя, дружелюбно, коротко (до 4 предложений), без markdown.")
            .put("messages", history)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val raw = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (!ok) throw Exception("HTTP ${c.responseCode}")
        return JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
