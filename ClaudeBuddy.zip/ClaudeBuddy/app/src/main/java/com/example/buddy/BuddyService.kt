package com.example.buddy

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.method.ScrollingMovementMethod
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BuddyService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var buddy: BuddyView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var answer: TextView
    private lateinit var bg: GradientDrawable
    private var u = 1f
    private var mode = "idle"
    private var busy = false
    private var expanded = false
    private val history = JSONArray()
    private val closeTask = Runnable { if (!busy) collapse() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        u = resources.displayMetrics.density
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "Buddy", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "buddy")
            .setContentTitle("Claude Buddy работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
        h.post(clock)
    }

    private fun dp(v: Int) = (v * u).toInt()
    private fun imm() = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
    private fun setMode(m: String) { mode = m; buddy.mood = m }

    private val labels = mapOf("happy" to "Радуется", "laugh" to "Смеётся", "love" to "Тронут",
        "surprised" to "Удивлён", "sad" to "Грустит", "confused" to "Не понял",
        "offended" to "Обиделся", "angry" to "Сердится")

    private fun hour() = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    private fun baseMood() = if (hour() >= 23 || hour() < 6) "sleepy" else "idle"

    private fun applyPalette() {
        val hr = hour()
        when {
            hr in 5..9 -> buddy.setPalette(0xFFF0883A.toInt(), 0xFFFFE6C8.toInt())
            hr in 10..16 -> buddy.setPalette(0xFF4FA8DB.toInt(), 0xFFE0F2FB.toInt())
            hr in 17..21 -> buddy.setPalette(0xFFEE7BA3.toInt(), 0xFFFFE3EC.toInt())
            else -> buddy.setPalette(0xFF7A6BC4.toInt(), 0xFFE6E1F8.toInt())
        }
        if (mode == "idle" || mode == "sleepy") setMode(baseMood())
    }

    private val clock = object : Runnable {
        override fun run() { applyPalette(); h.postDelayed(this, 60000) }
    }

    private fun build() {
        buddy = BuddyView(this).apply {
            scaleF = 0.5f
            setOnClickListener { if (expanded) { if (!busy) collapse() } else openInput() }
        }
        status = TextView(this).apply {
            visibility = View.GONE; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), 0, 0, 0)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(buddy); addView(status)
        }
        input = EditText(this).apply {
            visibility = View.GONE; hint = "Спросите…"; isSingleLine = true
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF8A8A93.toInt())
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(0xFF26262B.toInt()); cornerRadius = dp(16).toFloat() }
            setOnEditorActionListener { _, a, _ ->
                if (a == EditorInfo.IME_ACTION_SEND) {
                    val t = text.toString().trim()
                    if (t.isNotEmpty() && !busy) { text.clear(); ask(t) }
                    true
                } else false
            }
        }
        answer = TextView(this).apply {
            visibility = View.GONE; textSize = 15f; setTextColor(0xFFFFFFFF.toInt())
            maxHeight = dp(200)
            movementMethod = ScrollingMovementMethod()
            setOnClickListener { if (!busy) collapse() }
        }
        bg = GradientDrawable().apply { setColor(0xFF000000.toInt()); cornerRadius = dp(20).toFloat() }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg
            addView(header)
            addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            addView(answer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        style(false)
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
        lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = sb + dp(2)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        setMode(baseMood())
        wm.addView(root, lp)
    }

    private fun style(exp: Boolean) {
        expanded = exp
        root.minimumWidth = if (exp) dp(300) else 0
        bg.cornerRadius = dp(if (exp) 24 else 20).toFloat()
        root.setPadding(dp(if (exp) 14 else 12), dp(if (exp) 8 else 2), dp(if (exp) 14 else 12), dp(if (exp) 12 else 2))
        status.visibility = if (exp) View.VISIBLE else View.GONE
    }

    private fun focusable(f: Boolean) {
        lp.flags = if (f) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, lp)
    }

    private fun openInput() {
        h.removeCallbacks(closeTask)
        style(true); status.text = "Слушаю…"; setMode("listen")
        answer.visibility = View.GONE; input.visibility = View.VISIBLE
        focusable(true)
        input.requestFocus()
        h.postDelayed({ imm().showSoftInput(input, 0) }, 150)
    }

    private fun collapse() {
        h.removeCallbacks(closeTask)
        imm().hideSoftInputFromWindow(input.windowToken, 0)
        input.visibility = View.GONE; answer.visibility = View.GONE
        style(false); setMode(baseMood()); focusable(false)
    }

    private fun ask(text: String) {
        h.removeCallbacks(closeTask)
        busy = true; setMode("think"); status.text = "Думаю…"
        imm().hideSoftInputFromWindow(input.windowToken, 0)
        input.visibility = View.GONE; answer.visibility = View.GONE
        focusable(false)
        while (history.length() > 8) history.remove(0)
        history.put(JSONObject().put("role", "user").put("content", text))
        Thread {
            val r = try { Result.success(call()) } catch (e: Exception) { Result.failure(e) }
            h.post { finish(r) }
        }.start()
    }

    private fun finish(r: Result<String>) {
        busy = false
        r.onSuccess { raw ->
            val m = Regex("^\\s*\\[(\\w+)\\]\\s*").find(raw)
            val tag = m?.groupValues?.get(1)?.lowercase() ?: "happy"
            val text = if (m != null) raw.substring(m.range.last + 1) else raw
            val emo = if (labels.containsKey(tag)) tag else "happy"
            history.put(JSONObject().put("role", "assistant").put("content", text))
            status.text = labels[emo] ?: "Готово"; answer.text = text; answer.visibility = View.VISIBLE
            setMode(emo)
            h.postDelayed({ if (mode == emo) setMode(baseMood()) }, 4500)
            h.postDelayed(closeTask, 8000L + text.length * 50L)
        }.onFailure {
            history.remove(history.length() - 1)
            status.text = "Ошибка"; answer.text = it.message ?: "неизвестная ошибка"; answer.visibility = View.VISIBLE
            setMode("sad")
            h.postDelayed({ if (mode == "sad") setMode(baseMood()) }, 2500)
            h.postDelayed(closeTask, 9000)
        }
    }

    private val sys = "Ты милый маленький зверёк-талисман на экране телефона. Отвечай на языке пользователя, коротко (до 3 предложений), без markdown. Всегда начинай ответ ровно с одного тега эмоции в квадратных скобках: [happy] обычный дружелюбный ответ, [laugh] если смешно, [love] если пользователь благодарит или хвалит, [surprised] если что-то удивительное, [sad] если пользователю грустно или плохо, [confused] если непонятно, [offended] если в сообщении пользователя есть орфографические ошибки или опечатки: тогда обидься понарошку, мягко и с юмором, скажи что тебе обидно читать с ошибками, но всё равно помоги, [angry] если пользователь ругается или оскорбляет: тогда коротко посердись и попроси говорить вежливо, без грубости и оскорблений. Тег пиши только в самом начале."

    private fun post(url: String, body: JSONObject, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val raw = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (!ok) {
            val msg = try { JSONObject(raw).getJSONObject("error").getString("message") } catch (_: Exception) { "" }
            throw Exception("HTTP ${c.responseCode} ${msg.take(120)}")
        }
        return raw
    }

    private fun call(): String {
        val key = (getSharedPreferences("buddy", MODE_PRIVATE).getString("key", "") ?: "").trim()
        if (key.isEmpty()) throw Exception("не задан ключ")
        if (!key.startsWith("sk-ant")) {
            // Google Gemini (бесплатный ключ из AI Studio)
            val contents = JSONArray()
            for (i in 0 until history.length()) {
                val m = history.getJSONObject(i)
                contents.put(JSONObject()
                    .put("role", if (m.getString("role") == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.getString("content")))))
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents)
            val prefs = getSharedPreferences("buddy", MODE_PRIVATE)
            val models = mutableListOf("gemini-3.5-flash", "gemini-3-flash-preview", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash")
            prefs.getString("model", null)?.let { models.remove(it); models.add(0, it) }
            var raw: String? = null
            var last: Exception? = null
            for (m in models) {
                try {
                    raw = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                        body, mapOf("x-goog-api-key" to key))
                    prefs.edit().putString("model", m).apply()
                    break
                } catch (e: Exception) {
                    last = e
                    if (e.message?.startsWith("HTTP 404") != true) throw e
                }
            }
            if (raw == null) throw (last ?: Exception("нет доступной модели"))
            return JSONObject(raw!!).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
        // Anthropic Claude
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", sys).put("messages", history)
        val raw = post("https://api.anthropic.com/v1/messages", body,
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
        return JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
