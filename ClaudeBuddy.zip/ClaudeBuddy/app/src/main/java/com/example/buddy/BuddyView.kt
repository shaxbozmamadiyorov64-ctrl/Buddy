package com.example.buddy

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

class BuddyView(c: Context) : View(c) {
    var mood = "idle"
    var scaleF = 1f
    private var base = 0xFFF0883A.toInt()
    private var light = 0xFFFFE6C8.toInt()
    private val dens = resources.displayMetrics.density
    private val u: Float get() = dens * scaleF
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val ink = 0xFF1B1530.toInt()
    private val tick = object : Runnable {
        override fun run() { invalidate(); postOnAnimation(this) }
    }

    fun setPalette(b: Int, l: Int) { base = b; light = l; invalidate() }

    override fun onMeasure(a: Int, b: Int) = setMeasuredDimension((84 * u).toInt(), (80 * u).toInt())
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    private fun fill(col: Int) { p.style = Paint.Style.FILL; p.color = col }
    private fun line(col: Int, w: Float) {
        p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    }
    private fun mix(a: Int, b: Int, f: Float): Int {
        val k = 1f - f
        return Color.argb(255,
            (Color.red(a) * k + Color.red(b) * f).toInt(),
            (Color.green(a) * k + Color.green(b) * f).toInt(),
            (Color.blue(a) * k + Color.blue(b) * f).toInt())
    }
    private fun heart(cv: Canvas, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy + s * 0.9f)
        path.cubicTo(cx - s * 1.6f, cy - s * 0.1f, cx - s * 0.7f, cy - s * 1.1f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.7f, cy - s * 1.1f, cx + s * 1.6f, cy - s * 0.1f, cx, cy + s * 0.9f)
        path.close()
        cv.drawPath(path, p)
    }

    override fun onDraw(cv: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f
        var dx = 0f; var dy = 0f; var rot = 0f; var s = 1f
        when (mood) {
            "idle" -> dy = sin(t * 2.2f) * 1.5f
            "sleepy" -> dy = sin(t * 1.2f) * 2f
            "listen" -> { s = 1.07f; dy = -2f }
            "think" -> rot = sin(t * 7f) * 5f
            "happy" -> dy = -abs(sin(t * 9f)) * 10f
            "laugh" -> { dy = -abs(sin(t * 12f)) * 5f; rot = sin(t * 26f) * 4f }
            "sad" -> dy = 3f
            "offended" -> { dx = 4f; rot = 6f }
            "angry" -> rot = sin(t * 32f) * 2.5f
            "surprised" -> dy = -abs(sin(t * 5f)) * 4f
            "love" -> s = 1f + 0.04f * sin(t * 8f)
            "confused" -> rot = sin(t * 3f) * 5f
        }
        val body = if (mood == "angry") mix(base, 0xFFE24B4A.toInt(), 0.5f) else base
        val face = if (mood == "angry") mix(light, 0xFFFFC9C4.toInt(), 0.6f) else light

        cv.save()
        cv.translate(width / 2f, height - 6f * u)
        cv.scale(u, u)
        cv.translate(dx, dy); cv.rotate(rot); cv.scale(s, s)

        fill(body)
        path.reset(); path.moveTo(-34f, -38f); path.lineTo(-31f, -66f); path.lineTo(-11f, -50f); path.close(); cv.drawPath(path, p)
        path.reset(); path.moveTo(34f, -38f); path.lineTo(31f, -66f); path.lineTo(11f, -50f); path.close(); cv.drawPath(path, p)
        fill(mix(face, 0xFFF4A3B8.toInt(), 0.5f))
        path.reset(); path.moveTo(-29f, -42f); path.lineTo(-28f, -58f); path.lineTo(-16f, -49f); path.close(); cv.drawPath(path, p)
        path.reset(); path.moveTo(29f, -42f); path.lineTo(28f, -58f); path.lineTo(16f, -49f); path.close(); cv.drawPath(path, p)
        fill(body); r.set(-36f, -52f, 36f, -4f); cv.drawRoundRect(r, 24f, 24f, p)
        fill(face); r.set(-30f, -47f, 30f, -8f); cv.drawRoundRect(r, 20f, 20f, p)

        val ch = when (mood) { "offended" -> 8f; "love" -> 6f; else -> 4.5f }
        fill(if (mood == "love" || mood == "offended") 0x88FF6F91.toInt() else 0x55FF7A9A.toInt())
        cv.drawCircle(-24f, -17f, ch, p); cv.drawCircle(24f, -17f, ch, p)

        val blink = mood == "idle" && (t % 3.7f) > 3.58f
        for (sd in intArrayOf(-1, 1)) {
            val x = sd * 14f
            val y = -30f
            when {
                mood == "happy" || mood == "laugh" -> {
                    line(ink, 2.8f); r.set(x - 5f, y - 4f, x + 5f, y + 6f); cv.drawArc(r, 200f, 140f, false, p)
                }
                mood == "love" -> { fill(0xFFFF5C8A.toInt()); heart(cv, x, y, 3.6f + sin(t * 8f) * 0.5f) }
                mood == "sleepy" -> {
                    line(ink, 2.4f); r.set(x - 5f, y - 4f, x + 5f, y + 4f); cv.drawArc(r, 20f, 140f, false, p)
                }
                blink -> { line(ink, 2.4f); cv.drawLine(x - 5f, y, x + 5f, y, p) }
                mood == "surprised" -> {
                    fill(0xFFFFFFFF.toInt()); cv.drawCircle(x, y, 6.5f, p)
                    line(ink, 1.2f); cv.drawCircle(x, y, 6.5f, p)
                    fill(ink); cv.drawCircle(x, y, 2.6f, p)
                }
                else -> {
                    var er = 4.5f; var ox = 0f; var oy = 0f
                    when (mood) {
                        "listen" -> er = 5.8f
                        "think" -> oy = -2.5f
                        "offended" -> ox = 2.2f
                        "angry" -> er = 3.8f
                        "confused" -> er = if (sd < 0) 5.6f else 3.4f
                        "sad" -> oy = 1.5f
                    }
                    fill(ink); cv.drawCircle(x + ox, y + oy, er, p)
                    fill(0xFFFFFFFF.toInt()); cv.drawCircle(x + ox + 1.6f, y + oy - 1.6f, 1.4f, p)
                    if (mood == "offended") {
                        fill(face); cv.drawRect(x - 7f + ox, y - 7f, x + 7f + ox, y - 0.5f, p)
                        line(ink, 2f); cv.drawLine(x - 5f + ox, y - 0.5f, x + 5f + ox, y - 0.5f, p)
                    }
                }
            }
        }

        line(ink, 2.2f)
        when (mood) {
            "angry" -> { cv.drawLine(-21f, -40f, -9f, -35f, p); cv.drawLine(21f, -40f, 9f, -35f, p) }
            "sad" -> { cv.drawLine(-20f, -37f, -9f, -40f, p); cv.drawLine(20f, -37f, 9f, -40f, p) }
            "offended" -> { cv.drawLine(-20f, -39f, -9f, -37f, p); cv.drawLine(20f, -37f, 9f, -39f, p) }
            "surprised" -> { cv.drawLine(-19f, -42f, -9f, -42f, p); cv.drawLine(19f, -42f, 9f, -42f, p) }
            "confused" -> { cv.drawLine(-20f, -43f, -9f, -40f, p); cv.drawLine(9f, -37f, 20f, -37f, p) }
        }

        when (mood) {
            "happy", "love" -> { line(ink, 2.6f); r.set(-8f, -24f, 8f, -10f); cv.drawArc(r, 10f, 160f, false, p) }
            "laugh" -> {
                fill(ink); r.set(-7f, -22f, 7f, -9f); cv.drawOval(r, p)
                fill(0xFFFF8FA3.toInt()); r.set(-4f, -14f, 4f, -9.5f); cv.drawOval(r, p)
            }
            "sad" -> { line(ink, 2.4f); r.set(-6f, -18f, 6f, -9f); cv.drawArc(r, 200f, 140f, false, p) }
            "offended" -> { line(ink, 2.2f); r.set(-4f, -17f, 4f, -11f); cv.drawArc(r, 200f, 140f, false, p) }
            "angry" -> {
                line(ink, 2.2f); path.reset()
                path.moveTo(-7f, -13f); path.lineTo(-3.5f, -17f); path.lineTo(0f, -13f)
                path.lineTo(3.5f, -17f); path.lineTo(7f, -13f); cv.drawPath(path, p)
            }
            "surprised" -> { fill(ink); r.set(-3.5f, -20f, 3.5f, -11f); cv.drawOval(r, p) }
            "confused" -> {
                line(ink, 2.2f); path.reset(); path.moveTo(-7f, -15f)
                path.quadTo(-3.5f, -19f, 0f, -15f); path.quadTo(3.5f, -11f, 7f, -15f); cv.drawPath(path, p)
            }
            "think" -> {
                fill(0xFF7B4FD6.toInt())
                for (i in -1..1) {
                    p.alpha = (255 * (0.4f + 0.6f * abs(sin(t * 5f + i)))).toInt()
                    cv.drawCircle(i * 5f, -15f, 2f, p)
                }
            }
            "sleepy" -> { line(ink, 2f); r.set(-3f, -18f, 3f, -12f); cv.drawArc(r, 20f, 140f, false, p) }
            else -> { line(ink, 2.4f); r.set(-6f, -22f, 6f, -12f); cv.drawArc(r, 20f, 140f, false, p) }
        }

        when (mood) {
            "sad" -> { fill(0xFF6CB4F5.toInt()); cv.drawCircle(-19f, -24f + (t * 8f) % 9f, 1.8f, p) }
            "angry" -> {
                fill(0xCCFFFFFF.toInt()); val k = (t * 18f) % 12f
                cv.drawCircle(-27f, -62f - k, 2.4f, p); cv.drawCircle(27f, -62f - k * 0.8f, 2.4f, p)
            }
            "sleepy" -> {
                fill(0xAA1B1530.toInt()); p.textSize = 14f; p.typeface = Typeface.DEFAULT_BOLD
                cv.drawText("z", 24f, -50f - (t * 6f) % 6f, p)
            }
        }
        cv.restore()
    }
}
