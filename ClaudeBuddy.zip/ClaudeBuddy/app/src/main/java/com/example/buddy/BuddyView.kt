package com.example.buddy

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

class BuddyView(c: Context) : View(c) {
    var mood = "walk"   // walk, idle, listen, think, happy, sad
    var dir = 1
    private val u = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val tick = object : Runnable {
        override fun run() { invalidate(); postOnAnimation(this) }
    }

    override fun onMeasure(a: Int, b: Int) = setMeasuredDimension((84 * u).toInt(), (80 * u).toInt())
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f
        var dy = 0f; var rot = 0f; var s = 1f
        when (mood) {
            "walk" -> { dy = -abs(sin(t * 7)) * 6 * u; rot = sin(t * 7) * 3 }
            "think" -> rot = sin(t * 7) * 6
            "happy" -> dy = -abs(sin(t * 9)) * 16 * u
            "listen" -> { s = 1.06f; dy = -3 * u }
            "sad" -> dy = 3 * u
        }
        p.style = Paint.Style.FILL; p.color = 0x22000000
        cv.drawOval(width / 2f - 30 * u, height - 8 * u, width / 2f + 30 * u, height - 2 * u, p)

        cv.save()
        cv.translate(width / 2f, height - 6 * u)
        cv.scale(dir.toFloat(), 1f)
        cv.translate(0f, dy); cv.rotate(rot); cv.scale(s, s)

        // antenna
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * u; p.color = 0xFFBFA9E4.toInt()
        cv.drawLine(0f, -60 * u, 0f, -66 * u, p)
        p.style = Paint.Style.FILL; p.color = 0xFFFFB84D.toInt()
        cv.drawCircle(0f, -68 * u, 4 * u, p)
        // body
        r.set(-36 * u, -60 * u, 36 * u, -4 * u)
        p.color = 0xFFFBF7FF.toInt(); cv.drawRoundRect(r, 26 * u, 26 * u, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * u; p.color = 0xFFBFA9E4.toInt()
        cv.drawRoundRect(r, 26 * u, 26 * u, p)
        // cheeks
        p.style = Paint.Style.FILL; p.color = 0xB3F9B6C8.toInt()
        cv.drawCircle(-24 * u, -22 * u, 5 * u, p); cv.drawCircle(24 * u, -22 * u, 5 * u, p)
        // eyes
        p.color = 0xFF2A1A3A.toInt()
        if (mood == "happy") {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * u; p.strokeCap = Paint.Cap.ROUND
            for (x in floatArrayOf(-15f, 15f)) {
                r.set((x - 5) * u, -39 * u, (x + 5) * u, -29 * u); cv.drawArc(r, 200f, 140f, false, p)
            }
        } else {
            val er = if (mood == "listen") 5f * u else 4f * u
            cv.drawCircle(-15 * u, -34 * u, er, p); cv.drawCircle(15 * u, -34 * u, er, p)
        }
        // mouth
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f * u; p.strokeCap = Paint.Cap.ROUND
        when (mood) {
            "sad" -> { r.set(-8 * u, -22 * u, 8 * u, -10 * u); cv.drawArc(r, 200f, 140f, false, p) }
            "think", "listen" -> {
                p.style = Paint.Style.FILL; p.color = 0xFF7B4FD6.toInt()
                for (i in -1..1) {
                    val a = if (mood == "think") (0.4f + 0.6f * abs(sin(t * 5 + i))) else 1f
                    p.alpha = (255 * a).toInt()
                    cv.drawCircle(i * 8 * u, -18 * u, 2.6f * u, p)
                }
            }
            "happy" -> { r.set(-10 * u, -28 * u, 10 * u, -12 * u); cv.drawArc(r, 20f, 140f, false, p) }
            else -> { r.set(-8 * u, -26 * u, 8 * u, -14 * u); cv.drawArc(r, 20f, 140f, false, p) }
        }
        cv.restore()
    }
}
